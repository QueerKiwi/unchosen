declare module "*.svg"
declare module "*.txt"
