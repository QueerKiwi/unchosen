# How to use:

1. Download index.html from the releases section.
2. Edit index.html with an editor from https://github.com/Vizdun/values-common-editor/ or from the web editor at https://vizdun.github.io/values-common-editor/.